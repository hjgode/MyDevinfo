#include "MySensorPlugin.h"

#include "npfunctions.h"

#include <stdio.h>
#include <windows.h>

//  These are the method / property names our plugin object will export
static NPIdentifier sMonitor_id;
static NPIdentifier sPollInterval_id;
static NPIdentifier sCurrentValue_id;
static NPIdentifier sSensorType_id;


static NPObject * AllocateMySensorPluginObject(NPP npp, NPClass *aClass)
{
	//  Called in response to NPN_CreateObject
	MySensorPluginObject* obj = new MySensorPluginObject(npp);
	//  Setting the default properties of the created object.
	obj->m_iPollInterval = 3000;
	obj->m_iCurrentValue = 0;
	obj->m_hStopSensorMonitor = CreateEvent(NULL, FALSE, FALSE, NULL);
	obj->m_iSensorType = -1;

	//  Create a Hidden Window so our sensor thread can re-synchronize back
	//  to the main thread
	obj->hWindow = CreateWindow(L"SensorWindow", NULL, 0, 0, 0, 0, 0, NULL, (HMENU) 0, NULL, NULL);
	if (obj->hWindow == NULL)
	{
		WNDCLASS wndclass;
		memset (&wndclass, 0, sizeof wndclass);
		wndclass.lpfnWndProc = obj->NpapiProc;
		wndclass.hInstance = NULL;
		wndclass.lpszClassName = L"SensorWindow";
		RegisterClass (&wndclass);
		obj->hWindow = CreateWindow(L"SensorWindow", NULL, 0, 0, 0, 0, 0, NULL, (HMENU) 0, NULL, NULL);
	}
	SetWindowLong(obj->hWindow, GWL_WNDPROC, (DWORD)obj->NpapiProc);
	return obj;
}

//  NPAPI Macro
DECLARE_NPOBJECT_CLASS_WITH_BASE(MySensorPluginObject,
                                 AllocateMySensorPluginObject);

bool MySensorPluginObject::Construct(const NPVariant *args, uint32_t argCount,
                                     NPVariant *result)
{
	//  Where the JS Object is created, called when we say:
	//  var myObj = new MySensor();
	bool bRetVal = false;
	//  Create Object, expect no arguments
	if (argCount == 0)
	{
		NPObject* genericObj = NPN_CreateObject(mNpp, GET_NPOBJECT_CLASS(MySensorPluginObject));
		if (!genericObj)
			return false;
		MySensorPluginObject* obj = (MySensorPluginObject*)genericObj;
		OBJECT_TO_NPVARIANT(genericObj, *result);
		//  We have a function in our plugin to output text to a text box
		MessageToUser("Creating Sensor");
		bRetVal = true;
	}
  return bRetVal;
}

//  Called when the JS Object is destroyed
MySensorPluginObject::~MySensorPluginObject()
{
	SetEvent(m_hStopSensorMonitor);
}


bool MySensorPluginObject::HasMethod(NPIdentifier name)
{
	//  Called by the plugin framework to query whether an object
	//  has a specified method, we only have one method, 'monitor()'
	return (name == sMonitor_id);
}

bool MySensorPluginObject::HasProperty(NPIdentifier name)
{
	//  Called by the plugin framework to query whether a JS object
	//  has a specified property, we have three properties.
	return (name == sPollInterval_id ||
			name == sCurrentValue_id ||
			name == sSensorType_id);
}

bool MySensorPluginObject::GetProperty(NPIdentifier name, NPVariant *result)
{
	//  Retrieve the value of a property.  *result is an out parameter
	//  into which we should store the value
	bool bReturnVal = false;
	VOID_TO_NPVARIANT(*result);

	if (name == sCurrentValue_id)
	{
		//  Called by: var sensorVal = mySensor.currentValue;
		//  Return the current value to the web page.
		//  First truncate current value
		DOUBLE_TO_NPVARIANT(((float)this->m_iCurrentValue) / 100.0, *result);
		bReturnVal = true;
	}
	if (!bReturnVal)
		VOID_TO_NPVARIANT(*result);
	return bReturnVal;
}

bool MySensorPluginObject::SetProperty(NPIdentifier name, const NPVariant *value)
{
	//  Sets the specified property to the specified value.
	bool bRetVal = false;
	if (name == sSensorType_id)
	{
		//  mySensor.sensorType = 'temperature';
		char szSensor[1024];
		memset(szSensor, 0, 1024);
		sprintf(szSensor, NPVARIANT_TO_STRING(*value).UTF8Characters);
		if (strcmp(szSensor, "temperature") == 0)
			this->m_iSensorType = 0;
		else if (strcmp(szSensor, "pressure") == 0)
			this->m_iSensorType = 1;		
		bRetVal = true;
	}
	else if (name == sPollInterval_id)
	{
		//  mySensor.pollInterval = [value];
		this->m_iPollInterval = (int)NPVARIANT_TO_DOUBLE(*value);		

		//  NB:  If you want to return a string you need to allocate the memory for it
		//char* szReturnBuffer = (char*) NPN_MemAlloc(wcslen(value) + 1);
		//wcstombs(szReturnBuffer, tcUID, wcslen(value) + 1);
		//STRINGZ_TO_NPVARIANT(szReturnBuffer, *result);
		bRetVal = true;
	}
	return bRetVal;
}

char* MySensorPluginObject::npStrDup(const char* sIn)
{
	char* sOut = (char*)NPN_MemAlloc(strlen(sIn) + 1);
	if (sOut)
		strcpy(sOut, sIn);

	return sOut;
}

bool MySensorPluginObject::Invoke(NPIdentifier name, const NPVariant *args,
                               uint32_t argCount, NPVariant *result)
{
	//  Called when a method is called on an object
	bool bReturnVal = false;
	VOID_TO_NPVARIANT(*result);
	//  Convert to lower case to make our methods case insensitive
	char* szNameCmp = _strlwr(NPN_UTF8FromIdentifier(name));
	NPIdentifier methodName =  NPN_GetStringIdentifier(szNameCmp);
	NPN_MemFree(szNameCmp);
	//  mySensor.monitor(bool)
	if (methodName == sMonitor_id)
	{
		//  Expect one argument which is a boolean (start / stop)
		if (argCount == 1 && NPVARIANT_IS_BOOLEAN(args[0]))
		{
			if (NPVARIANT_TO_BOOLEAN(args[0]))
			{
				//  mySensor.monitor(true);
				//  Create a thread to monitor the sensor			
				CloseHandle(CreateThread(NULL, 0,
				(LPTHREAD_START_ROUTINE)SensorMonitorThread, this, 0, NULL));
			}
			else
			{
				//  mySensor.monitor(false);
				//  Stop monitoring the sensor
				SetEvent(m_hStopSensorMonitor);
			}
			//  Monitor has no return value
			VOID_TO_NPVARIANT(*result);
			bReturnVal = true;
		}
	}
	if (!bReturnVal)
		VOID_TO_NPVARIANT(*result);
	return bReturnVal;
}

//  This is where we simulate the Sensor by returning random values
//  based on the type of the sensor
DWORD MySensorPluginObject::SensorMonitorThread(LPVOID lpParameter)
{
	MySensorPluginObject* pSensor = (MySensorPluginObject*)lpParameter;
	bool exitThread = false;
	DWORD dwEvent;
	HANDLE hWaitHandles[1];
	hWaitHandles[0] = pSensor->m_hStopSensorMonitor;
	DEBUGMSG(TRUE, (L"Sensor Monitor Thread Starting\n"));

	while (true)
	{
		//  Wait for an exit event (indicating stop the thread) or timeout
		//  Note if we change the timeout value we have to wait until the next cycle
		//  before the new timeout value is read... this is just an example.
		dwEvent = WaitForMultipleObjects(
			1,
			hWaitHandles,
			FALSE,
			pSensor->m_iPollInterval);
		switch (dwEvent)
		{
		case WAIT_OBJECT_0:
			{
				goto _exitThread;
			}
		case WAIT_TIMEOUT:
			{
				//  Create a fake sensor reading to send to the page
				char szSensorReading[512];
				if (pSensor->m_iSensorType == 0)
				{
					float currentValue = (float)((rand() % 100 + 10000) / 100.0);
					//  truncate the output
					pSensor->m_iCurrentValue = (int)(currentValue * 100);
					sprintf(szSensorReading, "Sensor Reading: %.02f Kelvin", currentValue);
				}
				else
				{
					float currentValue = (float)((rand() % 100 + 1000) / 100.0);
					//  truncate the output
					pSensor->m_iCurrentValue = (int)(currentValue * 100);
					sprintf(szSensorReading, "Sensor Reading: %.02f Pascals", currentValue);
				}
				//  Contention here if timeout is too small but this is just a demo
				//  Resynchronise with the main thread.
				SendMessage(pSensor->hWindow, WM_USER + 1, (WPARAM)pSensor, (LPARAM)szSensorReading);
			}
		}  //  End Switch
	}	//  End While !exitThread
_exitThread:
	DEBUGMSG(TRUE, (L"Sensor Monitor Thread Exiting\n"));
	return 0;
}

//  Message handler for our hidden window to resynchronize with the main thread (NPAPI is not 
//  threadsafe)
LRESULT CALLBACK MySensorPluginObject::NpapiProc (HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	if (message == WM_USER + 1)
	{
		MySensorPluginObject* pSensor = (MySensorPluginObject*)wparam;
		char* szMessage = (char*)lparam;
		//  Inform the user that the sensor has a new value
		pSensor->MessageToUser(szMessage);
		return 0;
	}
	return DefWindowProc (hwnd, message, wparam, lparam);
}


bool MySensorPluginObject::InvokeDefault(const NPVariant *args, uint32_t argCount,
													NPVariant *result)
{
	STRINGZ_TO_NPVARIANT(npStrDup("default method return val"), *result);
	return true;
}

//  Constructor for the Plugin, called when the embedded mime type is found on a web page (see npp_new).
//  <embed id="embed1" type="application/x-motorolasolutions-mysensor" hidden=true> </embed> 
CMySensorPlugin::CMySensorPlugin(NPP pNPInstance) :
  m_pNPInstance(pNPInstance),
  m_pNPStream(NULL),
  m_bInitialized(FALSE),
  m_pScriptableObject(NULL)
{
	
  	// Must initialise this before getting NPNVPluginElementNPObject, as it'll
	// call back into our GetValue method and require a valid plugin.
	pNPInstance->pdata = this;

    // Say that we're a windowless plugin.
    NPN_SetValue(m_pNPInstance, NPPVpluginWindowBool, false);

	//  Instantiate the values of the methods / properties we possess
	sMonitor_id = NPN_GetStringIdentifier("monitor");
	sPollInterval_id = NPN_GetStringIdentifier("pollInterval");
	sCurrentValue_id = NPN_GetStringIdentifier("currentValue");
	sSensorType_id = NPN_GetStringIdentifier("sensorType");

	//  Export onto the webpage the JS object 'MySensor'.  This enables us
	//  to say var myObj = new MySensor();
	NPObject *sWindowObj;
	NPN_GetValue(m_pNPInstance, NPNVWindowNPObject, &sWindowObj);
	NPObject *mySensorObject =NPN_CreateObject(m_pNPInstance,GET_NPOBJECT_CLASS(MySensorPluginObject));
	NPVariant v;
	OBJECT_TO_NPVARIANT(mySensorObject, v);
	NPIdentifier n = NPN_GetStringIdentifier("MySensor");
	NPN_SetProperty(m_pNPInstance, sWindowObj, n, &v);
	NPN_ReleaseObject(mySensorObject);
	NPN_ReleaseObject(sWindowObj);

}

CMySensorPlugin::~CMySensorPlugin()
{

}

//  This code is called to update the box at the bottom of the page,
//  the Javascript function 'addSensorOutput' is invoked which interacts
//  with the DOM.
void MySensorPluginObject::MessageToUser(char* szMessage)
{
	NPVariant functionval;
	NPVariant rval;
	NPObject *sWindowObj;
	NPN_GetValue(mNpp, NPNVWindowNPObject, &sWindowObj);
	//  Populate 'functionval' with the name of our function
	NPN_GetProperty(mNpp, sWindowObj, NPN_GetStringIdentifier("addSensorOutput"), &functionval);
	NPVariant arg;
	if (NPVARIANT_TO_OBJECT(functionval) == 0)
		return;
	//  Create the argument to call 'addSensorOutput' with
	char szSourceMessage[1024];
	if (m_iSensorType == 0)
		sprintf(szSourceMessage, "Temperature: %s", szMessage);
	else if (m_iSensorType == 1)
		sprintf(szSourceMessage, "Pressure: %s", szMessage);
	else
		sprintf(szSourceMessage, "%s", szMessage);
	//  Add the string argument to our javascript function to an argument, 'arg'
	STRINGZ_TO_NPVARIANT(szSourceMessage, arg);
	//  Invoke the Javascript function on the page
	NPN_InvokeDefault(mNpp, NPVARIANT_TO_OBJECT(functionval), &arg, 1,
						&rval);
	//  Clean up allocated memory
	NPN_ReleaseVariantValue(&functionval);
	NPN_ReleaseVariantValue(&rval);
	NPN_ReleaseObject(sWindowObj);
}

NPBool CMySensorPlugin::init(NPWindow* pNPWindow)
{
  if(pNPWindow == NULL)
    return FALSE;

  if (SetWindow(pNPWindow))
      m_bInitialized = TRUE;

  return m_bInitialized;
}

void CMySensorPlugin::shut()
{
	m_bInitialized = FALSE;
}

NPBool CMySensorPlugin::isInitialized()
{
  return m_bInitialized;
}

NPError CMySensorPlugin::SetWindow(NPWindow* pNPWindow)
{
  if(pNPWindow == NULL)
    return FALSE;

  m_Window = pNPWindow;
  NPWindow* window = pNPWindow;
  return TRUE;
}


NPObject* CMySensorPlugin::GetScriptableObject()
{
	return NULL;
}
